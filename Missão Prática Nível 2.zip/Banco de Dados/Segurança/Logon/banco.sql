CREATE SEQUENCE PessoaSequence
    START WITH 1
    INCREMENT BY 1;

USE BancoDeDados;

CREATE TABLE PessoasFisicas (
    PessoaID INT PRIMARY KEY,
    Nome VARCHAR(255),
    CPF VARCHAR(14),
    Endereco VARCHAR(255),
    Telefone VARCHAR(20)
);

CREATE TABLE PessoasJuridicas (
    PessoaID INT PRIMARY KEY,
    NomeFantasia VARCHAR(255),
    CNPJ VARCHAR(18),
    Endereco VARCHAR(255),
    Telefone VARCHAR(20)
);

CREATE TABLE MovimentosCompra (
    MovimentoID INT PRIMARY KEY,
    ProdutoID INT,
    PessoaJuridicaID INT,
    Quantidade INT,
    PrecoUnitario DECIMAL(10, 2),
    DataHora DATETIME,
    FOREIGN KEY (ProdutoID) REFERENCES Produtos(ID),
    FOREIGN KEY (PessoaJuridicaID) REFERENCES PessoasJuridicas(PessoaID)
);

CREATE TABLE MovimentosVenda (
    MovimentoID INT PRIMARY KEY,
    ProdutoID INT,
    PessoaFisicaID INT,
    Quantidade INT,
    PrecoVendaAtual DECIMAL(10, 2),
    DataHora DATETIME,
    FOREIGN KEY (ProdutoID) REFERENCES Produtos(ID),
    FOREIGN KEY (PessoaFisicaID) REFERENCES PessoasFisicas(PessoaID)
);